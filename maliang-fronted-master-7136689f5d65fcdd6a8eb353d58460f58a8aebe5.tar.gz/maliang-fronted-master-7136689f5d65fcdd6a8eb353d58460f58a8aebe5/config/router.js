// 路由配置

// component 是相对于 src/pages 目录

// https://umijs.org/zh/guide/router.html#%E9%85%8D%E7%BD%AE%E5%BC%8F%E8%B7%AF%E7%94%B1

const routers = [
    {
        path: '/',
        component: '../layouts/index', // 外层布局
        routes: [
            { path: '/', component: './index'},//首页
            { path: '/vipsizeextend', redirect: '/vipsizeextend/styles' }, // 会员尺寸拓展
            { path: '/vipsizeextend/styles', component: './vipSizeExtend/styles' },
            { path: '/vipsizeextend/edit', component: './vipSizeExtend/edit' },
            { path: '/vipsizeextend/result', component: './vipSizeExtend/result' },
            { path: '/ipexpansion', redirect: './ipExpansion/upload' },  // IP延展
            { path: '/ipexpansion/upload', component: './ipExpansion/upload' },
            { path: '/ipexpansion/result', component: './ipExpansion/result' },
            { path: '/welfare', redirect: './welfare/styles' }, //福利图
            { path: '/welfare/styles', component: './welfareTemplate/styles' },
            { path: '/welfare/template', component: './welfareTemplate/template' },
            { path: '/welfare/edit', component: './welfareTemplate/edit' },
            { path: '/welfare/result', component: './welfareTemplate/result' },
            { path: '/gamesize', redirect: './gamesize/upload' }, //游戏尺寸拓展
            { path: '/gamesize/upload', component: './gameSizeExt/upload' },
            { path: '/gamesize/result', component: './gameSizeExt/result' },
            { path: '/elder', redirect: './elder/upload' }, //长辈式
            { path: '/elder/upload', component: './elderPoster/upload' },
            { path: '/elder/result', component: './elderPoster/result' },
            { path: '/test', component: './cutout/index' }, //测试抠图
            { path: '/manage', component: './manage/index' }, 
            { component: './index' }
        ],
    },
    
]

export default routers;
