import styles from './index.less'

// 加载动画
const Loading =  ({ tip, marginLeft }) => {
    return(
        <div className={styles.wrapper} style={{marginLeft: marginLeft}}>
            <div className={styles.loader}></div>
            {tip ? <div className={styles.tip}>{tip}</div> : null}
        </div>
    )
}

export default Loading;