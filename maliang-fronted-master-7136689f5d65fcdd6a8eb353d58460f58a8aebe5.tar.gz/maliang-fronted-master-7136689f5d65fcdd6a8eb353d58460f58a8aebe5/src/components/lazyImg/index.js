import { useState } from 'react'
import img from '../../assets/images/sizeExpansion/edit/底纹.png'

const LazyImg = ({ src, alt }) => {
    const [imgSrc, setSrc] = useState(img)

    function onLoad() {
        setSrc(src)
    }

    return (
        <img src={imgSrc} onLoad={onLoad} alt={alt || imgSrc } />
    )
}

export default LazyImg;