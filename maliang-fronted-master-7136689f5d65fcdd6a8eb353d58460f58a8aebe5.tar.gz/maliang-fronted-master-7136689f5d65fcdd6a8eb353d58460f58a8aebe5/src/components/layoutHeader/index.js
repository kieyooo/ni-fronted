// import { Divider } from 'antd'
import styles from './index.less'
import Link from 'umi/link';

// 全局导航
const LayoutHeader = () => {
    return (
        <div 
            className={styles.layoutHeader}
        >
            <Link className={styles.logo} to='/'>
                <img src={require('@/assets/logo.png')} alt='logo' />
            </Link>
            {/* <div className={styles.menu}>
                <span>智能创作</span>
                <span>我的作品</span>
                <span>实验室</span>
            </div>
            <div className={styles.right}>
                <div className={styles.help}>帮助</div>
                <Divider type='vertical' className={styles.divider} />
                <div className={styles.login}>立即登录</div>           
            </div> */}
        </div>
    )
}

export default LayoutHeader