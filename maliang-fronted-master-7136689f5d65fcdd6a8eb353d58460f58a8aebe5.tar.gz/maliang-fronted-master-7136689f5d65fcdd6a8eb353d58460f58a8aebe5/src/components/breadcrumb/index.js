import styles from './index.less'
import Link from 'umi/link'

// 面包屑路由
const WBreadcrumb = ({ routers }) => {
    return (
        <div className={styles.breadcrumb}>
            {routers && routers.map(val => (
                <span key={val.name}>
                {val.href
                    ? <Link to={val.href}>{val.name}</Link>
                    : <span>{val.name}</span>
                }
                <img src={require('@/assets/images/common/next.png')} alt='下一步' />
            </span>
            ))}
        </div>
    )
}

export default WBreadcrumb;