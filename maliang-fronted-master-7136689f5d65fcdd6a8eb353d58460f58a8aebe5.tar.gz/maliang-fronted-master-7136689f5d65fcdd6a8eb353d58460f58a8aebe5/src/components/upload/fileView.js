import React, { useState, forwardRef } from 'react'
import { connect } from 'dva'
import { Upload } from 'antd'
import styles from './fileView.less'

// 文件上传
function FileUpload({ sizeMB, accept, limit, fileList, dispatch }, ref) {

    const [fileError, setFileError] = useState('');
    
    function beforeUpload(file, fileList) {
        const fileType = accept.replace(/\./, '').split(',');
        const ext = file.name.split('.').pop();
        const isJPG = fileType.indexOf(ext) >= 0;
        const isLt2M = (file.size / 1024 / 1024).toFixed(2) < Number(sizeMB);
        const isLimit = fileList.length > Number(limit);
        if (!isJPG) {
            updateFileList([]) && setFileError('*请上传zip格式压缩包');
        }
        if (!isLt2M) {
            updateFileList([]) && setFileError('*压缩包最大不超过1GB')
        }
        if (isLimit) {
            updateFileList([]) && setFileError(`*一次最多上传${limit}个压缩包`)
        }
        !isLimit && isJPG && isLt2M && updateFileList(fileList) && setFileError('');
        return isJPG && isLt2M && isLimit;
    }

    function deleteFile(uid) {
        const file = fileList.filter(item => item.uid !== uid);
        updateFileList(file);
    }

    function updateFileList(file) {
        dispatch({
            type: 'file/setFile',
            payload: { file }
        });
        return true;
    }

    return (
        <div className={styles.wrapper} ref={ref}>
            <div className={styles.uploadContent}>
            <div className={styles.uploadBox}>
                <Upload
                    accept={accept || '*'}
                    multiple={Number(limit) > 1}
                    showUploadList={false}
                    beforeUpload={beforeUpload}
                >
                    <img src={require('@/assets/images/sizeExpansion/edit/1.png')} alt='图片上传' className={styles.uploadImg} />
                </Upload>
            </div>
            { fileError ? (
                <span className={styles.fileError}>{fileError}</span>
            ): null }
            {fileList && fileList.length !== 0 && fileList.map(val => (
                <div key={val.uid || val.name} className={styles.fileCard}>
                    <img src={require('@/assets/images/ipExpansion/archive.png')} alt='压缩包' className={styles.fileImg} />
                    <div className={styles.fileName}>{val.name}</div>
                    <div className={styles.fileSize}>{(val.size / 1024 / 1024).toFixed(2) + 'MB'}</div>
                    <img src={require('@/assets/images/ipExpansion/trash.png')} 
                        alt='垃圾桶' className={styles.trash} onClick={() => deleteFile(val.uid)} />
                </div>
            ))}
            </div>
        </div>
    )
}

export default connect(({ file }) => ({
    fileList: file.file
}))(forwardRef(FileUpload));