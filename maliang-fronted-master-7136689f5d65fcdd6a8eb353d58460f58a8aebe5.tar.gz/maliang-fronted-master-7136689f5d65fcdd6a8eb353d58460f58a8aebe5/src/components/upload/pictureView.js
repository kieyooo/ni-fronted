import React, { useState, forwardRef, useEffect } from 'react'
import { connect } from 'dva'
import { Upload, message, Progress } from 'antd'
import styles from './pictureView.less'

// 图片上传 + 预览
function PictureUpload({ sizeMB, accept, limit, fileList, dispatch }, ref) {
    const [previewUrl, setPreviewUrl] = useState('');
    const [precent, setPrecent] = useState(0);

    useEffect(() => {
        if (fileList[0] && fileList[0].preview) {
            setPreviewUrl(fileList[0].preview);
        }
        return () => {
            setPrecent(0);
            setPreviewUrl('')
        }
    }, [fileList])

    function beforeUpload(file, fileList) {
        setPrecent(0);
        const fileType = accept.replace(/\./, '').split(',');
        const ext = file.name.split('.').pop();
        const isJPG = fileType.indexOf(ext) >= 0;
        const isLt2M = (file.size / 1024 / 1024).toFixed(2) < Number(sizeMB);
        if (!isJPG) {
            message.warning(`文件类型不正确：${file.name}`)
        }
        if (!isLt2M) {
            message.warning(`文件超过大小限制：${file.name} 大于规定的${sizeMB}MB`)
        }
        isJPG && isLt2M && updateFileList(fileList) && handlePreview(file)
        return isJPG && isLt2M;
    }

    function updateFileList(file) {
        dispatch({
            type: 'file/setFile',
            payload: { file }
        });
        return true;
    }

    function getBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onprogress = (e) => {
                setPrecent((e.loaded / file.size).toFixed(2) * 100);
            };
            reader.onloadend = (e) => {
                setPreviewUrl(e.target.result)
            }
            reader.onload = () => resolve(reader.result);
            reader.onerror = error => reject(error);
        });
    }

    async function handlePreview(file) {
        file.preview = await getBase64(file);
        setPreviewUrl(file.url || file.preview)
    };

    return (
        <div className={styles.wrapper} ref={ref}>
            {fileList && fileList.length !== 0 ? (
                <div>
                    {previewUrl === '' && precent !== 100 ? (
                        <div className={styles.progessWrapper}>
                            <img src={require('@/assets/images/sizeExpansion/edit/shading.png')} alt='底纹' />
                            <img src={require('@/assets/images/sizeExpansion/edit/mask.png')} alt='蒙版' />                 
                            <div className={styles.progessBox}>
                                <Progress
                                    percent={precent}
                                    status='active'
                                    strokeWidth={14}
                                    style={{ width: '116px' }}
                                    showInfo={false}
                                    strokeColor='#495AE3'
                                />
                            </div>
                        </div>
                    ) : (
                            <div className={styles.previeWrapper}>
                                <img src={require('@/assets/images/sizeExpansion/edit/shading.png')} alt='底纹' />
                                <img src={previewUrl} alt='上传商品预览图' className={styles.previePic} />
                                <img src={require('@/assets/images/sizeExpansion/edit/mask.png')} alt='蒙版' className={styles.mengban} />
                                <div className={styles.changePicBox}>
                                    <Upload
                                        accept={accept || '*'}
                                        multiple={Number(limit) > 1}
                                        showUploadList={false}
                                        beforeUpload={beforeUpload}
                                        onPreview={getBase64}
                                    >
                                        <div className={styles.changePic}>更换图片</div>
                                    </Upload>
                                </div>
                            </div>
                        )}
                </div>
            ) : (
                    <Upload
                        accept={accept || '*'}
                        multiple={Number(limit) > 1}
                        showUploadList={false}
                        beforeUpload={beforeUpload}
                        onPreview={getBase64}
                    >
                        <img src={require('@/assets/images/sizeExpansion/edit/1.png')} alt='图片上传' className={styles.uploadImg} />
                    </Upload>
                )}
        </div>
    )
}

export default connect(({ file }) => ({
    fileList: file.file
}))(forwardRef(PictureUpload));