import { Carousel } from 'antd'
import styles from './index.less'

// 轮播图组件
// children => 传过来的轮播内容
//          形如： <div><img src={require('@/assets/images/首焦banner.png')} style={{width:'100%'}} alt='首焦banner' /></div>
//          div 包裹的是轮播内容
const WCarousel =  ({ children }) => {
    return (
        <div className={styles.carouselDotWrapper}>
          <Carousel>
            {children}
          </Carousel>
        </div>
    )
}

export default WCarousel;