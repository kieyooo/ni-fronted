import withRouter from 'umi/withRouter';
import LayoutHeader from '@/components/layoutHeader'
import styles from './index.less';

function BasicLayout(props) {
  return (
    <div className={styles.layoutWrapper}>
      <div className={styles.headerWrapper}>
        <LayoutHeader/>
      </div>
      <div className={styles.main}>
        {props.children}
      </div>
    </div>
  );
}

export default withRouter(BasicLayout);
