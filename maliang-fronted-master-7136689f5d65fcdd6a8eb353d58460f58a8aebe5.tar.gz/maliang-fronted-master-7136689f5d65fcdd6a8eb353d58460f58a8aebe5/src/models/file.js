export default {
    namespace: 'file',
    state: {
        file: []
    },
    effects: {
        *addFile({ payload }, { put, select }) {
            const { file } = yield select(state => state.file);
            const newFile = [].concat(file, payload.file)
            yield put({
                type: 'saveState',
                payload: {
                    file: newFile
                }
            })
        },
        *setFile({ payload }, { put }) {
            yield put({
                type: 'saveState',
                payload: {
                    ...payload
                }
            })
        },
        *removeFile() {
            
        }
    },
    reducers: {
        saveState(state, { payload }) {
            return {
                ...state,
                ...payload
            }
        }
    }
}