const walfare = [
    {
        "name": "美食",
        "value": "ms",
        "type": 'commom',
        "templates": [
            {
                "name": "orange",
                "value": "orange",
            },
            {
                "name": "red",
                "value": "red",
            },
            {
                "name": "yellow",
                "value": "yellow",
            },
            {
                "name": "blue",
                "value": "blue",
            },
            {
                "name": "green",
                "value": "green",
            },
            {
                "name": "purple",
                "value": "purple",
            }
        ]
    },
    {
        "name": "美妆",
        "value": "mz",
        "type": 'commom',
        "templates": [
            {
                "name": "lightpink",
                "value": "light pink",
            },
            {
                "name": "lightgreen",
                "value": "light green",
            },
            {
                "name": "lightblue",
                "value": "light blue",
            },
            {
                "name": "lightpurple",
                "value": "light purple",
            },
            {
                "name": "lightgold",
                "value": "light gold",
            },
            {
                "name": "lightgray",
                "value": "light gray",
            }
        ]
    },
    {
        "name": "商务",
        "value": "sw",
        "type": 'commom',
        "templates": [
            {
                "name": "beansandgreen",
                "value": "bean sand green",
            },
            {
                "name": "gold",
                "value": "gold",
            },
            {
                "name": "rosegold",
                "value": "rose gold",
            },
            {
                "name": "darkgreen",
                "value": "dark green",
            },
            {
                "name": "darkred",
                "value": "dark red",
            },
            {
                "name": "darkbrowm",
                "value": "dark browm",
            }
        ]
    },
    {
        "name": "商品",
        "value": "sp",
        "type": 'commom',
        "templates": [
            {
                "name": "lightorange",
                "value": "light orange",
            },
            {
                "name": "lightred",
                "value": "light red",
            },
            {
                "name": "green",
                "value": "green",
            },
            {
                "name": "skyblue",
                "value": "sky blue",
            },
            {
                "name": "lightyellow",
                "value": "lightyellow",
            },
            {
                "name": "purple",
                "value": "purple",
            }
        ]
    },
    // {
    //     "name": "代金券",
    //     "value": "djq",
    //     "type": 'other',
    //     "templates": [

    //     ]
    // },
    {
        "name": "logo",
        "value": "logo",
        "type": 'other',
        "templates": [
            {
                "name": "orange",
                "value": "orange",
            },
            {
                "name": "red",
                "value": "red",
            },
            {
                "name": "yellow",
                "value": "yellow",
            },
            {
                "name": "blue",
                "value": "blue",
            },
            {
                "name": "green",
                "value": "green",
            },
            {
                "name": "purple",
                "value": "purple",
            }
        ]
    },
]

export default walfare;