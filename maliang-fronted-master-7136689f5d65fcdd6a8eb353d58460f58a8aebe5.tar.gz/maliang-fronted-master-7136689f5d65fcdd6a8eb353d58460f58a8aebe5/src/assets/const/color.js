const colors = {
    '紫': 'purple',
    '橙': 'orange',
    '红': 'red',
    '蓝': 'blue',
    '绿': 'green',
    '黄': 'yellow'
}

export default colors;