// 主要存放一些变量

const testEnv = 'http://test.design.qiyi.domain'; //测试环境
const formalEnv = 'http://design.qiyi.domain' // 正式环境

module.exports =  {
    prefixUrl: formalEnv, //请求接口URL前缀
    vipSizeExtend: {
        //会员尺寸拓展文案最大长度
        lgHeader: 7, // 长文案主标题
        smHeader: 10, // 长文案副标题
        lgSubheader: 5, // 短文案主标题
        smSubheader: 6 //  短文案副标题
    },
    welfare: { // 福利图文案
        short: { // 短文案
            titleContent: 6,
            subtitleContent: 7, 
        },
        long: { // 长文案
            titleContent: 8,
            subtitleContent: 14,
        }
    }
    
}

