import httpWrapper from '@/utils/fetch'
import { prefixUrl } from '@/default'


export function vipExtendSubmit(fileUrl, payload) {
  const fd = new FormData();
  fd.append('img_url', fileUrl);
  fd.append('param', JSON.stringify(payload));

  return httpWrapper('post', `${prefixUrl}/posterobjectreplacement/submit`, fd);
}

export function vipExtendQuery(taskID) {
  const fd = new FormData();
  fd.append('taskId', taskID);
  return httpWrapper('post', `${prefixUrl}/posterobjectreplacement/query`, fd);
}