import httpWrapper from '@/utils/fetch'
import { prefixUrl } from '@/default'

export function elderPosterSubmit(fileUrl,is_zip = 1) {
    const fd = new FormData();
    fd.append('zip_url',fileUrl);
    fd.append('is_zip',is_zip)
    return httpWrapper('post', `${prefixUrl}/olderposter/submit`, fd);
}

export function elderPosterQuery(taskID) {
    const fd = new FormData();
    fd.append('taskId',taskID)
    return httpWrapper('post', `${prefixUrl}/olderposter/query`, fd);
}