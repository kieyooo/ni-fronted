import httpWrapper from '@/utils/fetch'
import { prefixUrl } from '@/default'

export function gameExtendSubmit(fileUrl) {
    return httpWrapper('post', `${prefixUrl}/psdexpansion/submit?url=${fileUrl}`);
}

export function gameExtendQuery(taskID) {
    return httpWrapper('post', `${prefixUrl}/psdexpansion/query?taskId=${taskID}`);
}