import httpWrapper from '@/utils/fetch'
import { prefixUrl } from '@/default'


export function ipExpansionSubmit(psdUrl, jsonUrl = '') {
  const fd = new FormData();
  fd.append('psd_url', psdUrl);
  fd.append('json_url', jsonUrl);
  return httpWrapper('post', `${prefixUrl}/movieposter/submit`, fd);
}

export function ipExpansionrQuery(taskID) {
  const fd = new FormData();
  fd.append('taskId', taskID);
  return httpWrapper('post', `${prefixUrl}/movieposter/query`, fd);
}