import httpWrapper from '@/utils/fetch'
import { prefixUrl } from '@/default'


export  default function uploadFile2Cloud(raw, config) {
    const fd = new FormData();
    fd.append('file', raw);
    return httpWrapper('post', `${prefixUrl}/uploadFormData`, fd, config);
}