import httpWrapper from '@/utils/fetch'
import { prefixUrl } from '@/default'

export default function welfareposter(payload) {
  return httpWrapper('post', `${prefixUrl}/welfareposter/batch`, payload)
}