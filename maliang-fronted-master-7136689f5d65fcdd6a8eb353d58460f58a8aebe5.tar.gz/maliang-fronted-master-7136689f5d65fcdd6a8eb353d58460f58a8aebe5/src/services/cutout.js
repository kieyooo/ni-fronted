import httpWrapper from '@/utils/fetch'
import { prefixUrl } from '@/default'


export function saveResult(base64,key) {
    const fd = new FormData();
    fd.append(key,base64)
    return httpWrapper('post',`${prefixUrl}/uploadSegmentationData`,fd)
}

export function getMask(url,key){
    return httpWrapper('post',`${prefixUrl}/segmentation`,{
        [key]: url
    })
}