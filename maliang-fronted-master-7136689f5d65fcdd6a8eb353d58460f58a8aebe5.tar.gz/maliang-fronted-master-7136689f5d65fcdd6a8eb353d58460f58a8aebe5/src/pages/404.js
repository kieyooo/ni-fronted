import { Button } from "antd";
import Link from 'umi/link';

export default () => {
    return (
        <div style={{textAlign:'center'}}>
            <h3>404</h3>
            <Button><Link to='/'>返回首页</Link></Button>
        </div>
    )
}