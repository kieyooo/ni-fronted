import { Card } from 'antd'
import Link from 'umi/link';
import WCarousel from '@/components/carousel'
import styles from './index.less';

// 首页
export default function () {
  return (
    <>
      {/* 轮播图 */}
      <Card bodyStyle={{ padding: '0px' }} bordered={false}>
        <WCarousel>
          <div><img src={require('@/assets/images/main/banner.png')} alt='banner' /></div>
          <div><img src={require('@/assets/images/main/banner.png')} alt='banner' /></div>
          <div><img src={require('@/assets/images/main/banner.png')} alt='banner' /></div>
        </WCarousel>
      </Card>
      {/* 智能设计 */}
      <Card bodyStyle={{ padding: '0px' }} bordered={false}>
        <div className={styles.intelDesHead}>
          <div className={styles.logo}></div>
          <div className={styles.mainTheme}>智能设计</div>
          <div className={styles.secTheme}>根据商品图批量设计各类场景图片</div>
        </div>
        <div className={styles.intelDesBody}>
          <Link to='/vipsizeextend'>
            <img src={require('@/assets/images/main/sizeexpansion.png')} alt='会员尺寸拓展' />
          </Link>
          <Link to='/welfare'>
            <img src={require('@/assets/images/main/welfare.png')} alt='福利图模板' />
          </Link>
          <Link to='/ipexpansion'>
            <img src={require('@/assets/images/main/ip.png')} alt='IP拓展' />
          </Link>
          <Link to='/gamesize'>
            <img src={require('@/assets/images/main/game.png')} alt='游戏尺寸拓展' />
          </Link>
          <Link to='/elder'>
            <img src={require('@/assets/images/main/elder.png')} alt='长辈式' />
          </Link>
          {/* <Link to='/'>
            <img src={require('@/assets/images/main/videoClip.png')} alt='视频剪辑' />
          </Link>
          <Link to='/'>
            <img src={require('@/assets/images/main/xianxiawuliao.png')} alt='线下物料' />
          </Link> */}
        </div>
      </Card>
    </>
  );
}
