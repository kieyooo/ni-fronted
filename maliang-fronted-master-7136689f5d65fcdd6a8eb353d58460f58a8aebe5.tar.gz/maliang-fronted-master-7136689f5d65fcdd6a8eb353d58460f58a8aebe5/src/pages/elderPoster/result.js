import React from 'react'
import WBreadcrumb from '@/components/breadcrumb'
import Link from 'umi/link'
import { connect } from 'dva'
import router from 'umi/router'
import styles from './index.less'

@connect(({ elder }) => ({
    downloadUrl: elder.downloadUrl,
    errMsg: elder.errMsg
}))
class Result extends React.Component {
    componentDidMount() {
        window.scrollTo && window.scrollTo(0, 0);
        const { downloadUrl, errMsg } = this.props;
        if (!downloadUrl && !errMsg) {
            router.push('/elder/upload')
        }
    }

    onDownload = () => {
        const { downloadUrl } = this.props;
        if (downloadUrl) {
            const a = document.createElement('a');
            a.href = downloadUrl[0];
            a.click();
            a.remove();
        }
    }

    componentWillUnmount() {
        const { dispatch } = this.props;
        dispatch({
            type: 'elder/changeState',
            payload: {
                downloadUrl: '',
                clearTimer: false,
                errMsg: '',
                stepMsg: '',
            }
        });
    }

    render() {
        const { errMsg } = this.props;
        return (
            <div className={styles.wrapper}>
                <WBreadcrumb
                    routers={[{ name: '长辈式' },
                    { name: '内容上传', href: '/elder/upload' },
                    { name: '生产结果', href: '/elder/result' }]}
                />
                <div className={styles.resultWrapper}>
                    {errMsg ? (
                        <>
                            <img src={require('@/assets/images/sizeExpansion/result/error.png')} alt='error' />
                            <div className={styles.text}>生产失败 !</div>
                            <div className={styles.errorMsg}>{errMsg}</div>
                            <Link to='/elder/upload' className={styles.edit}>返回修改</Link>
                        </>
                    ) : (
                            <>
                                <img src={require('@/assets/images/sizeExpansion/result/success.png')} alt='success' />
                                <div className={styles.text}>生产成功 !</div>
                                <div onClick={this.onDownload} className={styles.download}>开始下载</div>
                            </>
                        )}

                </div>
            </div>
        )
    }
}

export default Result;