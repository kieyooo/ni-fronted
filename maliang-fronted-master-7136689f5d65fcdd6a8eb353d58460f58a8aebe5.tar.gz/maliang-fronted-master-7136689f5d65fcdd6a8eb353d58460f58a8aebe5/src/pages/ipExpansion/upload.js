import React from 'react'
import { connect } from 'dva'
import { Form } from 'antd'
import WBreadcrumb from '@/components/breadcrumb'
import FileUpload from '@/components/upload/fileView'
import Loading from '@/components/pageloading'
import styles from './index.less'

@connect(({ file, ip, loading }) => ({
    fileList: file.file,
    stepMsg: ip.stepMsg,
    producing: loading.effects['ip/handleProcess']
}))
@Form.create()
class IPExpansionUpload extends React.Component {

    componentDidMount() {
        const { dispatch } = this.props;
        window.scrollTo && window.scrollTo(0, 0);
        dispatch({
            type: 'file/setFile',
            payload: { file: [] }
        });
        dispatch({
            type: 'ip/changeState',
            payload: {
                clearTimer: false,
            }
        });
    }

    checkFile = (rule, value, callback) => {
        const { fileList } = this.props;

        if (fileList.length > 0) {
            callback();
            return;
        }
        callback('*不得为空')
    }

    handleProcess = () => {
        const { fileList, dispatch } = this.props;
        if (fileList && fileList.length !== 0) {
            window.scrollTo && window.scrollTo(0, 0);
            dispatch({
                type: 'ip/changeState',
                payload: {
                    downloadUrl: '',
                    clearTimer: false,
                    errMsg: '',
                    stepMsg: '',
                }
            });
            dispatch({
                type: 'ip/handleProcess',
                payload: { file: fileList }
            })
        }
    }

    componentWillUnmount() {
        const { dispatch } = this.props;
        dispatch({
            type: 'ip/changeState',
            payload: {
                clearTimer: true,
            }
        });
    }

    render() {
        const { fileList, stepMsg, producing } = this.props
        return (
            <div className={styles.uploadWrapper}>
                <WBreadcrumb
                    routers={[{ name: 'IP延展' },
                    { name: '内容上传', href: '/ipexpansion/upload' }]}
                />
                {producing ? <Loading tip={stepMsg} marginLeft={'-94px'} /> : (
                    <>
                        <div className={styles.header}>
                            <div className={styles.mainTheme}>IP延展</div>
                            <div className={styles.secTheme}>IP EXPANSION</div>
                        </div>

                        <div className={styles.uploadBox}>
                            <div className={styles.Header}>
                                <img src={require('@/assets/images/common/dot.png')} alt='dot' />
                                <div>压缩包上传</div>
                                <span>{`(单个文件不超过 1 GB, 一次最多上传 1 个文件，仅支持zip格式)`}</span>
                            </div>
                            <div className={styles.uploadContent}>
                                <FileUpload
                                    accept='.zip'
                                    sizeMB='1024'
                                    limit='1'
                                />
                            </div>
                        </div>
                        <div className={styles.produceBtnWrapper}>
                            <img src={require('@/assets/images/common/mask.png')} alt='mask'/>
                            <div className={fileList && fileList.length !== 0 ? styles.produceBtn : `${styles.produceBtn} ${styles.disable}`}
                                onClick={this.handleProcess} >开始生成</div>
                        </div>

                    </>
                )}
            </div>
        )
    }
}


export default IPExpansionUpload;