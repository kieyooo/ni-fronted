import { delay } from '@/utils/util'
import uploadFile2Cloud from '@/services/uploadFile'
import { ipExpansionSubmit, ipExpansionrQuery } from '@/services/ipexpansion'
import router from 'umi/router'
import get from 'lodash/get'

export default {
    namespace: 'ip',
    state: {
        downloadUrl: '',
        clearTimer: false,
        errMsg: '',
        stepMsg: '',
    },
    effects: {
        *changeState({ payload }, { put }) {
            yield put({
                type: 'saveState',
                payload: { ...payload }
            })
        },
        *handleProcess({ payload }, { put, call, select }) {
            yield put({
                type: 'saveState',
                payload: { stepMsg: '正在将文件上传至云盘...'}
            });
            const uploadFileRes = yield call(uploadFile2Cloud, payload.file[0]);
            const psdUrl = get(uploadFileRes, 'data','');
            if (uploadFileRes.code !== 'A00000') {
                yield put({
                    type: 'saveState',
                    payload: { errMsg: '文件上传失败'}
                });
                router.push('/ipexpansion/upload');
                return;
            }
            yield put({
                type: 'saveState',
                payload: { stepMsg: '文件上传成功，AI生产中...'}
            });
            const submitRes = yield call(ipExpansionSubmit, psdUrl);
            const taskID = submitRes.data;
            if (!taskID) {
                yield put({
                    type: 'saveState',
                    payload: { errMsg: '触发生产失败，请重新上传'}
                });
                router.push('/ipexpansion/upload');
                return;
            }
            yield put({
                type: 'saveState',
                payload: { stepMsg: '正在生产中，请稍后...'}
            });
            let queryRes = null
            while(true) {
              queryRes = yield call(ipExpansionrQuery, taskID);
              yield call(delay, 3000);   
              const { clearTimer } = yield select(state => state.ip);
              if( clearTimer ) return;     
              if( queryRes.code !== 'A00107' ){
                break;
              }
            }
            if( get(queryRes, "data.info.error_code", 0) !== 0) {
                yield put({
                    type: 'saveState',
                    payload: { errMsg: get(queryRes, "data.info.error_msg", "")}
                });
                router.push('/ipexpansion/result');
                return;
            }
            if( get(queryRes, "data.info.service_error_code", "A00000") !== "A00000" ) {
                yield put({
                    type: 'saveState',
                    payload: { errMsg: get(queryRes, "data.info.service_error_msg", "")}
                });
                router.push('/ipexpansion/result');
                return;
            } 
            yield put({
                type: 'saveState',
                payload: { downloadUrl: get(queryRes, "data.swift_url","")}
            });
            router.push('/ipexpansion/result');
        }
    },
    reducers: {
        saveState(state, { payload }) {
            return {
                ...state,
                ...payload
            }
        }
    }
}