import React from 'react'
import moment from 'moment'
import { options, columns } from './options'
import { DatePicker, Table, Cascader, Row, Col, Card } from 'antd'

const { RangePicker } = DatePicker;


class Manage extends React.Component {

    onChange = (dates, dateStrings) => {
        console.log('From: ', dates[0], ', to: ', dates[1]);
        console.log('From: ', dateStrings[0], ', to: ', dateStrings[1]);
    }

    render() {
        return (
            <Card>
                <Row>
                    <Col span={1}>日期：</Col>
                    <Col span={10}>
                        <RangePicker
                            separator='-'
                            placeholder={['开始日期','结束日期']}
                            format='YYYY-MM-DD'
                            ranges={{
                                Today: [moment(), moment()],
                                'This Month': [moment().startOf('month'), moment().endOf('month')],
                            }}
                            onChange={this.onChange}
                        />
                    </Col>
                    <Col span={1}>模块：</Col>
                    <Col span={12}>
                        <Cascader 
                            options={options} 
                            changeOnSelect
                            placeholder='请选择'
                        />
                    </Col>
                </Row>
                <Table 
                    style={{marginTop:'50px'}}
                    columns={columns}
                    bordered
                />
            </Card>
        )
    }
}

export default Manage;