const options = [
    {
        value: 'all',
        label: '全部',
    },
    {
        value: 'utils',
        label: '实用工具',
        children: [
          {
            value: 'size',
            label: '会员尺寸拓展',
          },
          {
            value: 'game',
            label: '游戏尺寸拓展',
          },
          {
            value: 'ip',
            label: 'IP延展',
          },
          {
            value: 'cutout',
            label: '智能抠图',
          },
          {
            value: 'yasuo',
            label: '图片批量压缩',
          },
          {
            value: 'psd',
            label: '智能PSD标注',
          },
        ],
      },
]

const columns = [
    {
      title: '日期',
      dataIndex: 'date',
      align: 'center'
    },
    {
      title: '生产次数',
      dataIndex: 'time',
      align: 'center'
    },
  ];

export {
    options,
    columns
}