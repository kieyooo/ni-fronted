import React from 'react'
import WBreadcrumb from '@/components/breadcrumb'
import router from 'umi/router'
import { connect } from 'dva'
import styles from './index.less'

class Styles extends React.Component {
    componentDidMount() {
        const { dispatch } = this.props;
        dispatch({
            type: 'file/setFile',
            payload: { file: [] }
        });
        window.scrollTo && window.scrollTo(0,0);
        dispatch({
            type: 'vipsize/changeState',
            payload: {
                styleValue: '',
                downloadUrl: '',
                clearTimer: true,
                errMsg: '',
                stepMsg: '',
                lgHeader: '',
                smHeader: '',
                lgSubheader: '',
                smSubheader: '',
                lgHeaderLen: 0,
                smHeaderLen: 0,
                lgSubheaderLen: 0,
                smSubheaderLen: 0,
                zoom: 0.85,
                overlap: 15,
                needOverlap: 'disneed'
            }
        });
    }

    onStyleClick = (e) => {
        const { dispatch } = this.props
        if (e.target.alt) {
            dispatch({
                type: 'vipsize/changeState',
                payload: {
                    styleValue: e.target.alt
                }
            });
            router.push('/vipsizeextend/edit');
        }
    }
    render() {
        return (
            <div className={styles.stylesWrapper}>
                <WBreadcrumb
                    routers={[{ name: '会员尺寸拓展' }, { name: '风格选择', href: '/vipsizeextend/styles' }]}
                />
                <div className={styles.header}>
                    <div className={styles.mainTheme}>会员尺寸拓展</div>
                    <div className={styles.secTheme}>SIZE EXPANSION</div>
                </div>
                <div className={styles.stylesBox}>
                    <div className={styles.Header}>
                        <img src={require('@/assets/images/common/dot.png')} alt='dot' />
                        <div>风格选择</div>
                    </div>
                    <div className={styles.contentBody} onClick={this.onStyleClick}>
                        <img src={require('@/assets/images/sizeExpansion/stylesimgs/purple.png')} alt='紫' />
                        <img src={require('@/assets/images/sizeExpansion/stylesimgs/green.png')} alt='绿' />
                        <img src={require('@/assets/images/sizeExpansion/stylesimgs/blue.png')} alt='蓝' />
                        <img src={require('@/assets/images/sizeExpansion/stylesimgs/red.png')} alt='红' />
                        <img src={require('@/assets/images/sizeExpansion/stylesimgs/yellow.png')} alt='黄' />
                        <img src={require('@/assets/images/sizeExpansion/stylesimgs/orange.png')} alt='橙' />
                    </div>
                </div>
            </div>
        )
    }
}

export default connect()(Styles);