import React from 'react'
import WBreadcrumb from '@/components/breadcrumb'
import withRouter from 'umi/withRouter';
import Loading from '@/components/pageloading'
import colors from '@/assets/const/color'
import { connect } from 'dva'
import { Form, Input, Slider } from 'antd'
import router from 'umi/router'
import PictureUpload from '@/components/upload/pictureView'
import styles from './index.less'
import { vipSizeExtend } from '@/default'


@connect(({ vipsize, file, loading }) => ({
    ...vipsize,
    fileList: file.file,
    producing: loading.effects['vipsize/handleProcess'],
}))
@Form.create()
class Edit extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            collapse: true // 更多功能折叠状态，默认折叠
        }
    }

    changeCollapse = () => {
        const { collapse } = this.state;
        this.setState({
            collapse: !collapse
        })
    }

    componentDidMount() {
        const { styleValue, dispatch } = this.props;
        dispatch({
            type: 'vipsize/changeState',
            payload: {
                clearTimer: true,
            }
        });
        window.scrollTo && window.scrollTo(0, 0)
        if (styleValue === '') {
            router.push('/vipsizeextend/styles');
        }
    }

    checkFile = (rule, value, callback) => {
        const { fileList } = this.props;

        if (fileList.length > 0) {
            callback();
            return;
        }
        callback('*不得为空')
    }

    checkText = (rule, value, callback) => {
        const { dispatch } = this.props;
        const max = vipSizeExtend[rule.field]
        const type = rule.field;
        dispatch({
            type: 'vipsize/changeState',
            payload: { [`${type}Len`]: value.length }
        });
        if (value.length === 0) {
            callback('*不得为空');
            return;
        }
        if (value.length <= Number(max)) {
            callback();
            return;
        }
        callback(`*不得超过${max}个字`)
    }

    componentWillUnmount() {
        const { dispatch } = this.props;
        dispatch({
            type: 'vipsize/changeState',
            payload: {
                clearTimer: true,
            }
        });
    }

    produce = () => {
        this.props.form.validateFields({ force: true },(err, value) => {
            if (!err) {
                const { dispatch, fileList, styleValue, zoom, overlap, needOverlap } = this.props;
                const { lgHeader, lgSubheader, smHeader, smSubheader } = value;
                dispatch({
                    type: 'vipsize/changeState',
                    payload: {
                        lgHeader,
                        smHeader,
                        lgSubheader,
                        smSubheader,
                        downloadUrl: '',
                        clearTimer: false,
                        errMsg: '',
                        stepMsg: '',
                    }
                });
                const payload = {
                    other: {
                        ZBTD: lgHeader,
                        FBTD: lgSubheader,
                        ZBTX: smHeader,
                        FBTX: smSubheader,
                        TYPE: styleValue,
                        RESIZE: [zoom],
                    },
                    file: fileList
                }
                if (needOverlap === 'need') {
                    payload['other']['EFFECTS'] = [overlap]
                }

                if (fileList && fileList.length !== 0) {
                    dispatch({
                        type: 'vipsize/handleProcess',
                        payload
                    })
                }
            }

        });
    }

    render() {
        const { form: { getFieldDecorator }, producing, stepMsg, lgHeader,
            smHeader, lgSubheader, smSubheader, fileList, styleValue } = this.props;
        const { lgHeaderLen, smHeaderLen, lgSubheaderLen, smSubheaderLen } = this.props;
        const { collapse } = this.state;
        const color = colors[styleValue]
        return (
            <div className={styles.eidtWrapper}>
                <WBreadcrumb
                    routers={[{ name: '会员尺寸拓展' },
                    { name: '风格选择', href: '/vipsizeextend/styles' },
                    { name: '内容编辑', href: '/vipsizeextend/edit' }]}
                />
                {producing ? <Loading tip={stepMsg} marginLeft={'-94px'} /> : (
                    <>
                        <div className={styles.header}>
                            <div className={styles.mainTheme}>会员尺寸拓展</div>
                            <div className={styles.secTheme}>SIZE EXPANSION</div>
                        </div>
                        <Form>
                            <div className={styles.product}>
                                <div className={styles.Header}>
                                    <img src={require('@/assets/images/common/dot.png')} alt='dot' />
                                    <div>商品图</div>
                                </div>
                                <div className={styles.producContent}>
                                    <Form.Item>
                                        {getFieldDecorator('imgFile', {
                                            initialValue: fileList,
                                            rules: [{ validator: this.checkFile }],
                                        })(
                                            <PictureUpload
                                                accept='.png'
                                                sizeMB='5'
                                                limit='1'
                                            />)}
                                    </Form.Item>
                                </div>
                            </div>
                            <div className={styles.formItem}>
                                <div className={styles.Header}>
                                    <img src={require('@/assets/images/common/dot.png')} alt='dot' />
                                    <div>长文案</div>
                                </div>
                                <div className={styles.contentBody}>
                                    <div>
                                        <span>主标题</span>
                                        <Form.Item>
                                            {getFieldDecorator('lgHeader', {
                                                initialValue: lgHeader,
                                                rules: [{ validator: this.checkText }],
                                            })(<Input autoComplete="off" />)}
                                        </Form.Item>
                                        <span className={styles.numText}>{lgHeaderLen}/{vipSizeExtend['lgHeader']}</span>
                                    </div>
                                    <div>
                                        <span>副标题</span>
                                        <Form.Item>
                                            {getFieldDecorator('smHeader', {
                                                initialValue: smHeader,
                                                rules: [{ validator: this.checkText }],
                                            })(<Input autoComplete="off" />)}
                                        </Form.Item>
                                        <span className={styles.numText}>{smHeaderLen}/{vipSizeExtend['smHeader']}</span>
                                    </div>
                                </div>
                            </div>
                            <div className={styles.formItem}>
                                <div className={styles.Header}>
                                    <img src={require('@/assets/images/common/dot.png')} alt='dot' />
                                    <div>短文案</div>
                                    <span>{`(尺寸: 216×144 260×160 452×310 为短文案)`}</span>
                                </div>
                                <div className={styles.contentBody}>
                                    <div>
                                        <span>主标题</span>
                                        <Form.Item>
                                            {getFieldDecorator('lgSubheader', {
                                                initialValue: lgSubheader,
                                                rules: [{ validator: this.checkText }],
                                            })(<Input autoComplete="off" />)}
                                        </Form.Item>
                                        <span className={styles.numText}>{lgSubheaderLen}/{vipSizeExtend['lgSubheader']}</span>
                                    </div>
                                    <div>
                                        <span>副标题</span>
                                        <Form.Item>
                                            {getFieldDecorator('smSubheader', {
                                                initialValue: smSubheader,
                                                rules: [{ validator: this.checkText }],
                                            })(<Input autoComplete="off" />)}
                                        </Form.Item>
                                        <span className={styles.numText}>{smSubheaderLen}/{vipSizeExtend['smSubheader']}</span>
                                    </div>
                                </div>
                            </div>
                            <div className={styles.moreWrapper}>
                                <div className={styles.Header}>
                                    <img src={require('@/assets/images/sizeExpansion/edit/drop.png')} alt='下拉'
                                        onClick={this.changeCollapse} className={collapse ? styles.collapse : ''} />
                                    <div onClick={this.changeCollapse}>更多功能</div>
                                    <span>{`(即将开放)`}</span>
                                </div>
                                <div className={collapse ? `${styles.moreContent} ${styles.collapse}` : styles.moreContent}>
                                    <div>
                                        <img src={require('@/assets/images/sizeExpansion/edit/3.png')} alt='同心圆' />
                                        <span>主体物品缩放</span>
                                        <img src={require('@/assets/images/sizeExpansion/edit/size.png')} alt='大小'
                                            style={{ width: '14px', height: '20px' }} />
                                        <Slider defaultValue={85} min={0} max={100} disabled={true} />
                                        <div className={styles.curNum}>85%</div>
                                    </div>
                                    <div>
                                        <img src={require('@/assets/images/sizeExpansion/edit/3.png')} alt='同心圆' />
                                        <span>多图叠放</span>
                                        <img src={require('@/assets/images/sizeExpansion/edit/size.png')} alt='大小'
                                            style={{ width: '14px', height: '20px' }} />
                                        <Slider defaultValue={15} disabled={true} />
                                        <div className={styles.curNum}>15</div>
                                    </div>
                                    <img src={require(`@/assets/images/sizeExpansion/stylesimgs/${styleValue ? color : 'purple'}.png`)} alt='预览图'
                                        className={styles.pic} />
                                </div>
                            </div>
                        </Form>
                        <div className={styles.produceBtnWrapper}>
                            <img src={require('@/assets/images/common/mask.png')} alt='mask' />
                            <div onClick={this.produce} className={styles.produceBtn}>开始生成</div>
                        </div>
                    </>
                )}
            </div>
        )
    }
}

export default withRouter(Edit);