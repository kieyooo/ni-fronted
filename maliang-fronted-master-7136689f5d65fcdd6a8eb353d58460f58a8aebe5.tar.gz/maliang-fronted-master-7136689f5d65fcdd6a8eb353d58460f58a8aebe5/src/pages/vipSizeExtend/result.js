import React from 'react'
import WBreadcrumb from '@/components/breadcrumb'
import Link from 'umi/link'
import { connect } from 'dva'
import router from 'umi/router'
import styles from './result.less'

@connect(({ vipsize }) => ({
    downloadUrl: vipsize.downloadUrl,
    errMsg: vipsize.errMsg
}))
class Result extends React.Component {
    componentDidMount() {
        window.scrollTo && window.scrollTo(0, 0);
        const { downloadUrl, errMsg } = this.props;
        if (!downloadUrl && !errMsg) {
            router.push('/vipsizeextend/styles')
        }
    }

    onDownload = () => {
        const { downloadUrl } = this.props;      
        if (downloadUrl) {
            const a = document.createElement('a');
            a.href = downloadUrl;
            a.click();
            a.remove();
        }
        
    }
    render() {
        const { errMsg } = this.props;
        return (
            <div className={styles.wrapper}>
                <WBreadcrumb
                    routers={[{ name: '会员尺寸拓展' },
                    { name: '风格选择', href: '/vipsizeextend/styles' },
                    { name: '内容编辑', href: '/vipsizeextend/edit' },
                    { name: '生产结果', href: '/vipsizeextend/result' }]}
                />
                <div className={styles.resultWrapper}>
                    {errMsg ? (
                        <>
                            <img src={require('@/assets/images/sizeExpansion/result/error.png')} alt='error' />
                            <div className={styles.text}>生产失败 !</div>
                            <div className={styles.errorMsg}>{errMsg}</div>
                            <Link to='/vipsizeextend/edit' className={styles.edit}>返回修改</Link>
                        </>
                    ) : (
                            <>
                                <img src={require('@/assets/images/sizeExpansion/result/success.png')} alt='success' />
                                <div className={styles.text}>生产成功 !</div>
                                <div onClick={this.onDownload} className={styles.download}>开始下载</div>
                            </>
                        )}

                </div>
            </div>
        )
    }
}

export default Result;