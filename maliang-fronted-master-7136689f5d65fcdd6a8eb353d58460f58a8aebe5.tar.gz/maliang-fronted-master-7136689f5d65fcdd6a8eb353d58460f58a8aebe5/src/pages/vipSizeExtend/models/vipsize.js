import { delay } from '@/utils/util'
import uploadFile2Cloud from '@/services/uploadFile'
import { vipExtendSubmit, vipExtendQuery } from '@/services/vipsizeextend'
import router from 'umi/router'
import get from 'lodash/get'

export default {
    namespace: 'vipsize',
    state: {
        styleValue: '',
        downloadUrl: '',
        clearTimer: false,
        errMsg: '',
        stepMsg: '',
        lgHeader: '', 
        smHeader: '', 
        lgSubheader: '', 
        smSubheader: '', 
        lgHeaderLen: 0, // 长文案主标题
        smHeaderLen: 0, // 长文案副标题
        lgSubheaderLen: 0, // 短文案主标题
        smSubheaderLen: 0, //  短文案副标题
        zoom: 0.85,
        overlap: 15,
        needOverlap: 'disneed'
    },
    effects: {
        *changeState({ payload }, { put }) {
            yield put({
                type: 'saveState',
                payload: { ...payload }
            })
        },
        *handleProcess({ payload }, { put, call, select }) { 
            yield put({
                type: 'saveState',
                payload: { stepMsg: '正在将文件上传至云盘...'}
            });
            const uploadFileRes = yield call(uploadFile2Cloud, payload.file[0]);
            if (uploadFileRes.code !== 'A00000') {
                yield put({
                    type: 'saveState',
                    payload: { errMsg: '文件上传失败'}
                });
                router.push('/vipsizeextend/result');
                return;
            }
            const fileUrl = uploadFileRes.data;
            yield put({
                type: 'saveState',
                payload: { stepMsg: '文件上传成功，AI生产中...'}
            });
            const submitRes = yield call(vipExtendSubmit, fileUrl, payload.other);
            const taskID = submitRes.data;
            if (!taskID) {
                yield put({
                    type: 'saveState',
                    payload: { errMsg: '触发生产失败，请重新上传'}
                });
                router.push('/vipsizeextend/result');
                return;
            }
            yield put({
                type: 'saveState',
                payload: { stepMsg: '正在生产中，请稍后...'}
            });
            let queryRes = null
            while(true) {
              queryRes = yield call(vipExtendQuery, taskID);
              yield call(delay, 3000);   
              const { clearTimer } = yield select(state => state.vipsize)        
              if( clearTimer ) return;     
              if( queryRes.code !== 'A00107' ){
                break;
              }
            }
            if(get(queryRes, "data.info.error_code", 0) !== 0) {
                yield put({
                    type: 'saveState',
                    payload: { errMsg: get(queryRes, "data.info.error_msg", "")}
                });
                router.push('/vipsizeextend/result');
                return;
            }
            if(get(queryRes, "code", "A00000") !== "A00000" ) {
                yield put({
                    type: 'saveState',
                    payload: { errMsg: get(queryRes, "msg", "")}
                });
                router.push('/vipsizeextend/result');
                return;
            } 
            yield put({
                type: 'saveState',
                payload: { downloadUrl: get(queryRes, "data.swift_url", "")}
            });
            router.push('/vipsizeextend/result');
        }
    },
    reducers: {
        saveState(state, { payload }) {
            return {
                ...state,
                ...payload
            }
        }
    }
}