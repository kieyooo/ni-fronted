import uploadFile2Cloud from '@/services/uploadFile'
import { saveResult, getMask } from '@/services/cutout'
export default {
    namespace: 'svg',
    state: {
        base64: '',
        imgUrl: ''
    },
    effects: {
        *upload({ payload }, { call, put }) {
            // console.log(payload.file)
           const data =  yield call(uploadFile2Cloud, payload.file[0]);
           const res = yield call(getMask,data.data, '444');
           yield put.resolve({
            type: 'updateState',
            payload: { base64: res.data['444'].imageBase64 }
            })
        },
        *changeState({ payload }, { put }) {
            yield put.resolve({
                type: 'updateState',
                payload: {...payload}
            })
        },
        *save({ payload }, { call }) {
            yield call(saveResult,payload.base64, '444')
        }
    },
    reducers: {
        updateState(state, { payload }) {
            return {
                ...state,
                ...payload
            }
        }
    }
}