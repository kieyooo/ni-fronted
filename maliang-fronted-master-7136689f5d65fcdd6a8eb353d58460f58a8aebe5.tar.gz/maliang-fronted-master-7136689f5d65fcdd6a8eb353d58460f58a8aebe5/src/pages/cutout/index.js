import React from 'react'
import { SVG } from '@svgdotjs/svg.js'
import styles from './index.less'
import { saveSvgAsPng, svgAsPngUri } from 'save-svg-as-png'
import { Button, Upload, Icon } from 'antd';
import { connect } from 'dva'

@connect(({ svg }) => ({
    ...svg
}))
class SVGJS extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            lineArr: [],
            curIndex: 0
        }
    }

    componentDidMount() {
        window.scrollTo(0,0)
        var draw = SVG().addTo('#drawing').size(577, 433);
        this.draw = draw;
        // var image = draw.image(require('@/assets/0.jpg')).size(577, 433);
        // var maskImg = draw.image(require('@/assets/0_alpha.png')).size(577, 433);
        // var mask = draw.mask().add(maskImg);
        var mask = draw.mask();
        this.mask = mask;
        // image.maskWith(mask);
        var path = '';
        var polyline;
        var _this = this;
        window.addEventListener('mousedown', function drawStart() {

            draw.mousemove(function (e) {
                if (!polyline) {
                    polyline = draw.polyline();
                    mask.add(polyline);
                }
                path += `${e.offsetX},${e.offsetY} `;
                polyline.plot(path);

                polyline.fill('none').stroke({ width: '28.85', linecap: 'round', linejoin: 'round', color: '#fff' });
            })
        })
        window.addEventListener('mouseup', function drawEnd() {
            if (polyline) _this.changePath('add', polyline)
            path = '';
            polyline = null;
            draw.mousemove(null)
        })
    }

    componentWillReceiveProps(nextProps) {
        const { base64, imgUrl } = nextProps;
        if (base64 !== '' && imgUrl !== '') {
            // var base = this.getUrlBase64(imgUrl);
            var image = this.draw.image(imgUrl).size(577, 433);
            var maskImg = this.draw.image('data:image/png;base64,' + base64).size(577, 433);
            this.mask.add(maskImg);
            image.maskWith(this.mask);
        }
    }


    changePath = (type, line) => {
        const { lineArr, curIndex } = this.state;
        if (type === 'add') {
            const newLine = lineArr.concat(line);
            this.setState({
                lineArr: newLine,
                curIndex: newLine.length - 1
            })
        }
        if (type === 'prev') {
            if (curIndex >= 0) {
                lineArr[curIndex].remove();
                if (curIndex === 0) return;
                this.setState({
                    curIndex: curIndex - 1
                })
            }
        }
        if (type === 'next') {
            if (lineArr.length > curIndex) {
                this.mask.add(lineArr[curIndex]);
                if (curIndex === lineArr.length - 1) return;
                this.setState({
                    curIndex: curIndex + 1
                })
            }
        }
    }

    beforeUpload = (file, fileList) => {
        this.getbase64(fileList[0])
        this.uploadFile(fileList);
        return true;
    }

    getbase64 = (file) => {
        const { dispatch } = this.props
        var reader = new FileReader();
        reader.onload = function (e) {
            dispatch({
                type: 'svg/changeState',
                payload: { imgUrl: e.target.result }
            })
        }
        reader.readAsDataURL(file)
    }

    uploadFile = (file) => {
        const { dispatch } = this.props;
        dispatch({
            type: 'svg/upload',
            payload: {
                file
            }
        })
    }

    download = () => {
        saveSvgAsPng(document.getElementById('drawing').children[0], 'test.png', {
            encoderOptions: 1
        })
    }

    saveResult = () => {
        const { dispatch } = this.props;
        svgAsPngUri(document.getElementById('drawing').children[0]).then(uri => {
            console.log(uri)
            var mimeString = uri.split(',')[0].split(':')[1].split(';')[0]; // mime类型
            var byteString = atob(uri.split(',')[1]); //base64 解码
            var arrayBuffer = new ArrayBuffer(byteString.length); //创建缓冲数组
            var intArray = new Uint8Array(arrayBuffer); //创建视图

            for (var i = 0; i < byteString.length; i++) {
                intArray[i] = byteString.charCodeAt(i);
            }
            const blob = new Blob([intArray], { type: mimeString })
            console.log(blob) 
            dispatch({
                type: 'svg/save',
                payload: {
                    base64: blob
                }
            })
        })
    }

    componentWillUnmount() {
        window.removeEventListener('mousedown', function drawStart() { });
        window.removeEventListener('mouseup', function drawEnd() { });
    }

    render() {
        const { src } = this.state;
        console.log(src)
        return (
            <div>
                <Upload
                    beforeUpload={this.beforeUpload}
                    // multiple={true}
                    showUploadList={false}
                >
                    <Button>
                        <Icon type="upload" /> Click to Upload
                    </Button>
                </Upload>
                <div id='drawing' className={styles.back}></div>
                <Button onClick={() => this.changePath('prev')}>上一步</Button>
                <Button onClick={() => this.changePath('next')}>下一步</Button>
                <Button onClick={this.download}>下载</Button>
                <Button onClick={this.saveResult}>上传</Button>
            </div>

        )
    }
}
export default SVGJS