import React, { useEffect, useState } from 'react'
import { connect } from 'dva'
import WBreadcrumb from '@/components/breadcrumb'
import styles from './result.less'
import router from 'umi/router'
import Link from 'umi/link'
import { prefixUrl } from '@/default'
import { uniq, difference } from 'lodash'

const Result = ({ resultImgs, errMsg }) => {
    const [curSize, setCurSize] = useState(resultImgs.length !== 0 && 0);
    const [selectedLsit, setSelected] = useState([]);
    const [prevPic, setPrevPic] = useState({ url: '', size: '' })
    const totalNum = getTotalNum(resultImgs)
    useEffect(() => {
        if (resultImgs && resultImgs.length === 0) {
            router.push('/welfare/edit')
        }
    })

    function getTotalNum(arr) {
        let total = 0;
        for(let i = 0; i < arr.length; i++ ) {
            total += arr[i]["imgs"] && arr[i]["imgs"].length
        }
        return {
            total
        }
    }

    function downloadImgs(url) {
        if (!url || url.length === 0) return;
        const a = document.createElement('a');      
        if (Array.isArray(url)) {
            a.href = `${prefixUrl}/welfareposter/download?pics=${url.join(',')}`
        } else {
            a.href = `${prefixUrl}/welfareposter/download?pics=${url}`
        }
        a.click();
        a.remove()
    }

    function closeMask(e) {
        e.preventDefault();
        setPrevPic({ url: '', size: '' });
    }

    return (
        <>
            {prevPic.url ? (
                <div className={styles.prevPicWrapper}>
                    <div onClick={closeMask}></div>
                    <img src={prevPic.url} alt='预览图' title={prevPic.url} className={styles[prevPic.size]} />
                </div>
            ) : null}
            <div className={styles.wrapper}>
                <WBreadcrumb
                    routers={[{ name: '福利图模板' }, { name: '分类选择', href: '/welfare/styles' },
                    { name: '模板选择', href: '/welfare/template' }, { name: '内容编辑', href: '/welfare/edit' },
                    { name: '生产结果', href: '/welfare/result' }]}
                />
                <div className={styles.resultWrapper}>
                    {errMsg ? (
                        <>
                            <img src={require('@/assets/images/sizeExpansion/result/error.png')} alt='error' />
                            <div className={styles.text}>生产失败 !</div>
                            <div className={styles.errorMsg}>{errMsg}</div>
                            <Link to='/welfare/edit' className={styles.edit}>返回修改</Link>
                        </>
                    ) : (
                            <>
                                <img src={require('@/assets/images/sizeExpansion/result/success.png')} alt='success' />
                                <div className={styles.text}>生产成功 !</div>
                            </>
                        )}
                </div>
                <div className={styles.total}>
                    <span>共生成&nbsp;&nbsp;<span>{totalNum.total}</span>&nbsp;&nbsp;个结果</span>
                    <span><span>{totalNum.total}</span>&nbsp;&nbsp;个已生成</span>
                    <span><span>0</span>&nbsp;&nbsp;个待生产</span>
                    <span><span className={styles.failed}>0</span>&nbsp;&nbsp;个失败</span>
                </div>
                <div className={styles.size}>
                    <div className={styles.Header}>
                        <img src={require('@/assets/images/common/dot.png')} alt='dot' />
                        <div>尺寸过滤</div>
                    </div>
                    <div className={styles.sizeFilter} >
                        {resultImgs && resultImgs.map((val, idx) => (
                            <div key={val.size} onClick={() => setCurSize(idx)}
                                className={curSize === idx ? `${styles.selected}` : ''}>{val.size}</div>
                        ))}
                    </div>
                    <div className={styles.cards}>
                        {resultImgs && resultImgs[curSize] && resultImgs[curSize]["imgs"].map(val => (
                            <div key={val.shadingTemplateName} className={styles[resultImgs[curSize].size]}>
                                <img src={val.url} alt={val.shadingTemplateName} />
                                <div>
                                    {selectedLsit.includes(val.url) ? (
                                        <img src={require('@/assets/images/welfare/result/selected.png')} alt='选择'
                                            className={styles.select} onClick={() => setSelected(selectedLsit.filter(item => item !== val.url))} />
                                    ) : (<img src={require('@/assets/images/welfare/result/notSelected.png')} alt='未选择'
                                        className={styles.select} onClick={() => setSelected(selectedLsit.concat(val.url))} />)}
                                    <img src={require('@/assets/images/welfare/result/magnifier.png')} alt='放大' 
                                        onClick={() => setPrevPic({url: val.url, size: resultImgs[curSize]['size']})} />
                                    <img src={require('@/assets/images/welfare/result/download.png')} alt='下载'
                                        onClick={() => downloadImgs(val.url)} />
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
                <div className={styles.toolWrapper}>
                    <div className={styles.tool}>
                        {difference(resultImgs[curSize] && resultImgs[curSize]["imgs"].map(val => val.url), selectedLsit).length === 0 ? (
                            <img src={require('@/assets/images/welfare/result/selected.png')} alt='选择'
                                onClick={() => setSelected(difference(selectedLsit, resultImgs[curSize]["imgs"].map(val => val.url)))} />
                        ) : (
                                <img src={require('@/assets/images/welfare/result/notSelected.png')} alt='未选择'
                                    onClick={() => setSelected(uniq(selectedLsit.concat(resultImgs[curSize]["imgs"].map(val => val.url))))} />
                            )}

                        <span className={styles.all}>全选</span>
                        <span>已选</span>
                        <span className={styles.num}>{selectedLsit.length || 0}</span>
                        <span>张</span>
                        
                        <span className={styles.download} onClick={() => downloadImgs(selectedLsit)}>开始下载</span>
                        <span onClick={() => setSelected([])} className={styles.cancel}>一键取消</span>
                    </div>
                </div>
            </div>
        </>
    )
}

export default connect(({ welfare }) => ({
    resultImgs: welfare.resultImgs,
    errMsg: welfare.errMsg,
    sizeList: welfare.sizeList
}))(Result);