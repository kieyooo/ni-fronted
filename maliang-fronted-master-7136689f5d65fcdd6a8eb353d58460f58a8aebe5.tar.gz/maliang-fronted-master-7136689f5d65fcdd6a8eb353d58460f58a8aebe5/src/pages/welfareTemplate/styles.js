import React from 'react'
import WBreadcrumb from '@/components/breadcrumb'
import router from 'umi/router'
import walfare from '@/assets/const/walfare'
import { connect } from 'dva'
import styles from './index.less'

@connect()
class Styles extends React.Component {
    componentDidMount() {
        const { dispatch } = this.props;
        window.scrollTo && window.scrollTo(0, 0);
        dispatch({
            type: 'file/setFile',
            payload: { file: [] }
        });
        dispatch({
            type: 'welfare/changeState',
            payload: {
                stylesValue: '',
                templateValue: '',
                sizeList: [],
                titleContent: '',
                subtitleContent: '',
                titleContentLen: 0,
                subtitleContentLen: 0,
                resultImgs: [],
                stepMsg: '',
                errMsg: ''
            }
        })
    }

    onStyleClick = (e) => {
        const value = e.target.alt;
        const { dispatch } = this.props;
        if ( value ) {
            dispatch({
                type: 'welfare/changeState',
                payload: {
                    stylesValue: value
                }
            });
            router.push('/welfare/template')
        }
    }

    render() {
        return (
            <div className={styles.stylesWrapper}>
                <WBreadcrumb
                    routers={[{ name: '福利图模板' }, { name: '分类选择', href: '/welfare/styles' }]}
                />
                <div className={styles.header}>
                    <div className={styles.mainTheme}>福利图模板</div>
                    <div className={styles.secTheme}>WELFARE TEMPLATE</div>
                </div>
                <div className={styles.commonBox}>
                    <div className={styles.Header}>
                        <img src={require('@/assets/images/common/dot.png')} alt='dot' />
                        <div>常用分类</div>
                    </div>
                    <div className={styles.contentBody} onClick={this.onStyleClick}>
                        {walfare && walfare.map(val => {
                            return val.type === 'commom' && <img src={require(`@/assets/images/welfare/stylesimgs/${val.value}.png`)}
                                alt={val.value} key={val.name} />
                        })}
                    </div>
                </div>
                {/* <div className={styles.otherBox}>
                    <div className={styles.Header}>
                        <img src={require('@/assets/images/common/dot.png')} alt='dot' />
                        <div>其他分类</div>
                    </div>
                    <div className={styles.contentBody} onClick={this.onStyleClick}>
                        {walfare && walfare.map(val => {
                            return val.type === 'other' && <img src={require(`@/assets/images/welfare/stylesimgs/${val.name}.png`)}
                                alt={val.value} key={val.name} />
                        })}
                    </div>
                </div> */}
            </div>
        )
    }
}

export default Styles;