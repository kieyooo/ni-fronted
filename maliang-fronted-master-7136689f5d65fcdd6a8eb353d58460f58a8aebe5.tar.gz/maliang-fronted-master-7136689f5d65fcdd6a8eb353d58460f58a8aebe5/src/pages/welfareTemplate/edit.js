import React from 'react'
import WBreadcrumb from '@/components/breadcrumb'
import PictureUpload from '@/components/upload/pictureView'
import Loading from '@/components/pageloading'
import router from 'umi/router'
import { connect } from 'dva'
import styles from './index.less'
import { Form, Input } from 'antd'
import { welfare } from '@/default'

@connect(({ file, welfare, loading }) => ({
    fileList: file.file,
    ...welfare,
    producing: loading.effects['welfare/handleProcess']
}))
@Form.create()
class Edit extends React.Component {

    componentDidMount() {
        const { stylesValue, templateValue } = this.props;
        if (stylesValue === '') router.push('/welfare/styles');
        if (templateValue === '') router.push('/welfare/template');
    }

    onChangeSize = (e) => {
        const { sizeList, dispatch } = this.props;
        const curClass = e.target.className;
        const curValue = e.target['dataset']['value'];
        const index = sizeList.indexOf(curValue);
        e.preventDefault();
        if (curValue && !curClass.includes(`${styles.disable}`)) {
            if (index === -1) {
                dispatch({
                    type: 'welfare/changeState',
                    payload: { sizeList: sizeList.concat(curValue) }
                })
            } else {
                dispatch({
                    type: 'welfare/changeState',
                    payload: { sizeList: sizeList.filter(val => val !== curValue) }
                })
            }
        }

    }

    checkFile = (rule, value, callback) => {
        const { fileList } = this.props;

        if (fileList.length > 0) {
            callback();
            return;
        }
        callback('*不得为空')
    }

    checkText = (rule, value, callback) => {
        const { dispatch, sizeList } = this.props;
        const txtType = sizeList.includes('348x192') ? 'short' : 'long';
        const max = welfare[txtType][rule.field]
        const type = rule.field;
        dispatch({
            type: 'welfare/changeState',
            payload: { [`${type}Len`]: value.length, [`${type}`]: value }
        });
        if (value.length <= Number(max)) {
            callback();
            return;
        }
        callback(`*不得超过${max}个字`)
    }

    produce = () => {
        this.props.form.validateFields({ force: true },(err) => {
            const { dispatch, fileList, sizeList } = this.props;
            if (!err && sizeList.length !== 0) {
                window.scrollTo && window.scrollTo(0, 0);
                dispatch({ type: 'welfare/handleProcess', payload: { file: fileList } })
            }
        })
    }

    render() {
        const { form: { getFieldDecorator }, fileList, sizeList,
            titleContent, subtitleContent, titleContentLen, subtitleContentLen, producing, stepMsg } = this.props;
        const is348X192 = sizeList.indexOf('348x192') !== -1
        const isNot348x192 = sizeList.indexOf('210x210') !== -1 ||
            sizeList.indexOf('716x192') !== -1 ||
            sizeList.indexOf('750x210') !== -1 || false;
        const txtType =  sizeList.length === 0 ? 'short' : sizeList.includes('348x192') ? 'short' : 'long';
        return (
            <div className={styles.editWrapper}>
                <WBreadcrumb
                    routers={[{ name: '福利图模板' }, { name: '分类选择', href: '/welfare/styles' },
                    { name: '模板选择', href: '/welfare/template' }, { name: '内容编辑', href: '/welfare/edit' }]}
                />
                {producing ? <Loading tip={stepMsg} marginLeft={'-94px'}/> : (
                    <>
                        <div className={styles.header} >
                            <div className={styles.mainTheme}>福利图模板</div>
                            <div className={styles.secTheme}>WELFARE TEMPLATE</div>
                        </div>
                        <Form>
                            <div className={styles.product}>
                                <div className={styles.Header}>
                                    <img src={require('@/assets/images/common/dot.png')} alt='dot' />
                                    <div>商品图</div>
                                </div>
                                <div className={styles.producContent}>
                                    <Form.Item>
                                        {getFieldDecorator('imgFile', {
                                            initialValue: fileList,
                                            rules: [{ validator: this.checkFile }],
                                        })(
                                            <PictureUpload
                                                accept='.png'
                                                sizeMB='5'
                                                limit='1'
                                            />)}
                                    </Form.Item>
                                </div>
                            </div>
                            <div className={styles.size}>
                                <div className={styles.Header}>
                                    <img src={require('@/assets/images/common/dot.png')} alt='dot' />
                                    <div>尺寸</div>
                                    <span>{`(尺寸: 210x210 716x192 750x210可多选)`}</span>
                                </div>
                                <div className={styles.contentBody} onClick={this.onChangeSize}>
                                    <div data-value='210x210' className={`${is348X192 ? styles.disable : ''} ${sizeList.includes('210x210') ? styles.selected : ''}`}>210x210</div>
                                    <div data-value='348x192' className={`${isNot348x192 ? styles.disable : ''} ${sizeList.includes('348x192') ? styles.selected : ''}`}>348x192</div>
                                    <div data-value='716x192' className={`${is348X192 ? styles.disable : ''} ${sizeList.includes('716x192') ? styles.selected : ''}`}>716x192</div>
                                    <div data-value='750x210' className={`${is348X192 ? styles.disable : ''} ${sizeList.includes('750x210') ? styles.selected : ''}`}>750x210</div>
                                </div>
                            </div>
                            <div className={styles.formItem}>
                                <div className={styles.Header}>
                                    <img src={require('@/assets/images/common/dot.png')} alt='dot' />
                                    <div>{txtType === 'short' ?  "短文案" : "长文案"}</div>
                                </div>
                                <div className={styles.contentBody}>
                                    <div>
                                        <span>主标题</span>
                                        <Form.Item>
                                            {getFieldDecorator('titleContent', {
                                                initialValue: titleContent,
                                                rules: [{ validator: this.checkText }],
                                            })(<Input autoComplete="off" />)}
                                        </Form.Item>
                                        <span className={styles.numText}>{titleContentLen}/{welfare[txtType]['titleContent']}</span>
                                    </div>
                                    <div>
                                        <span>副标题</span>
                                        <Form.Item>
                                            {getFieldDecorator('subtitleContent', {
                                                initialValue: subtitleContent,
                                                rules: [{ validator: this.checkText }],
                                            })(<Input autoComplete="off" />)}
                                        </Form.Item>
                                        <span className={styles.numText}>{subtitleContentLen}/{welfare[txtType]['subtitleContent']}</span>
                                    </div>
                                </div>
                            </div>
                        </Form>
                        <div className={styles.produceBtnWrapper}>
                            <img src={require('@/assets/images/common/mask.png')} alt='mask' />
                            <div className={styles.produceBtn}
                                onClick={this.produce} >开始生成</div>
                        </div>
                    </>
                )}
            </div>
        )
    }
}

export default Edit;