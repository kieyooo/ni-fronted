import uploadFile2Cloud from '@/services/uploadFile'
import welfareposter from '@/services/welfare'
import router from 'umi/router'
import get from 'lodash/get'

export default {
    namespace: 'welfare',
    state: {
        stylesValue: '',
        templateValue: '',
        sizeList: [],
        titleContent: '',
        subtitleContent: '',
        titleContentLen: 0,
        subtitleContentLen: 0,
        resultImgs: [],
        stepMsg: '',
        errMsg: ''
    },
    effects: {
        *changeState({ payload }, { put }) {
            yield put({
                type: 'saveState',
                payload: { ...payload }
            })
        },
        *handleProcess({ payload }, { put, call, select }) {
            yield put({
                type: 'saveState',
                payload: { stepMsg: '正在将文件上传至云盘...' }
            });
            const uploadFileRes = yield call(uploadFile2Cloud, payload.file[0]);
            if (uploadFileRes.code !== 'A00000') {
                yield put({
                    type: 'saveState',
                    payload: { errMsg: '文件上传失败' }
                });
                router.push('/welfare/result');
                return;
            } else {
                yield put({
                    type: 'saveState',
                    payload: { stepMsg: '文件上传成功，正在AI生产中' }
                });
            }
            const logoUrl = get(uploadFileRes, 'data', '');
            const {
                stylesValue: sceneName,
                templateValue: shadingTemplateName,
                sizeList,
                titleContent,
                subtitleContent
            } = yield select(state => state.welfare);
            const singlePayload = {
                sceneName,
                logoUrl,
                sizeList,
                titleContent: titleContent || "null",
                subtitleContent: subtitleContent || "null"
            };
            const action = "1"
                .repeat(8)
                .split("")
                .map((_, index) => ({
                    ...singlePayload,
                    shadingTemplateName: `${shadingTemplateName}${index + 1}`
                }));
            const _res = yield call(welfareposter, action);
            if( _res.code !== "A00000") {
                yield put({
                    type: 'saveState',
                    payload: { errMsg: get(_res, "msg", "AI生产失败") }
                });
                router.push('/welfare/result');
                return;
            } else {
                const allData = get(_res, "data", []);
                const allImagesMappedBySize = sizeList.map(size => {
                    const allImagesOfTheSizeFromTemplates = [];
                    for (let i = 0; i < allData.length; i++) {
                      if (allData[i]["imageUrls"][`${size}`]) {
                        allImagesOfTheSizeFromTemplates.push({
                          url: allData[i]["imageUrls"][`${size}`],
                          shadingTemplateName: allData[i]["shadingTemplateName"]
                        })
                      }
                    }
                    return {
                      size,
                      imgs: allImagesOfTheSizeFromTemplates
                    };
                });
                yield put({
                    type: 'saveState',
                    payload: {
                        resultImgs: allImagesMappedBySize
                    }
                });
                router.push('/welfare/result');          
            }
        }
    },
    reducers: {
        saveState(state, { payload }) {
            return {
                ...state,
                ...payload
            }
        }
    }
}