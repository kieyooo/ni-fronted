import React from 'react'
import WBreadcrumb from '@/components/breadcrumb'
import walfare from '@/assets/const/walfare'
import router from 'umi/router'
import { connect } from 'dva'
import styles from './index.less'

@connect(({ welfare }) => ({
    stylesValue: welfare.stylesValue
}))
class Template extends React.Component {
    componentDidMount() {
        const { stylesValue } = this.props;
        if (stylesValue === '') {
            router.push('/welfare/styles')
        }
    }

    onTemplateClick = (e) => {
        const value = e.target.alt;
        const { dispatch } = this.props;
        if(value) {
            dispatch({
                type: 'welfare/changeState',
                payload: {
                    templateValue: value
                }
            });
            router.push('/welfare/edit')
        }
    }

    render() {
        const { stylesValue } = this.props
        const [{ templates }] = stylesValue ? walfare.filter(val => val.value === stylesValue) : [{ "templates": [] }];
        return (
            <div className={styles.templateWrapper}>
                <WBreadcrumb
                    routers={[{ name: '福利图模板' }, { name: '分类选择', href: '/welfare/styles' },
                    { name: '模板选择', href: '/welfare/template' }]}
                />
                <div className={styles.header}>
                    <div className={styles.mainTheme}>福利图模板</div>
                    <div className={styles.secTheme}>WELFARE TEMPLATE</div>
                </div>
                <div className={styles.templateBox}>
                    <div className={styles.Header}>
                        <img src={require('@/assets/images/common/dot.png')} alt='dot' />
                        <div>模板选择</div>
                    </div>
                    <div className={styles.contentBody} onClick={this.onTemplateClick}>
                        { templates && templates.length !== 0 && templates.map(val => {
                            const path = require(`@/assets/images/welfare/templateImgs/${stylesValue}/${val.name}.png`);
                            return <img src={path} alt={val.value} key={val.name} />
                        })}
                    </div>
                </div>
            </div>
        )
    }
}

export default Template;