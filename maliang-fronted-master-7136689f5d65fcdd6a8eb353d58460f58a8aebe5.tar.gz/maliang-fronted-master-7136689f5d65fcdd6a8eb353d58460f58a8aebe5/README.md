## 马良平台前端

### 安装模块
```
npm install
```

### 本地启动
```
npm start
```

### 打包
```
npm run build
```