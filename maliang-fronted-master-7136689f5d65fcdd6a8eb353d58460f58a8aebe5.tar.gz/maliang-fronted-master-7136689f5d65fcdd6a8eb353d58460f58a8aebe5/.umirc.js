import routers from './config/router'
// ref: https://umijs.org/config/
export default {
  treeShaking: true,
  history:'hash',
  targets: {
    ie: 11,
  },
  define: {

  },
  hash: true,
  routes: routers,
  plugins: [
    // ref: https://umijs.org/plugin/umi-plugin-react.html
    ['umi-plugin-react', {
      antd: true,
      dva: {
        hmr: true,
      },
      dynamicImport: { 
        loadingComponent: './components/pageloading/index',
        webpackChunkName: true,
        level: 3,
      },
      title: 'maliang-fronted',
      // dll: true,
      
      routes: {
        exclude: [
          /models\//,
          /services\//,
          /model\.(t|j)sx?$/,
          /service\.(t|j)sx?$/,
          /components\//,
        ],
      },
    }],
  ],
}
